# MMC‑MMS — Architecture (Frontend ⇄ Core Middleware ⇄ API ⇄ Supabase)

```mermaid
flowchart LR
  A[Browser / Vite Web App] -- fetch /api/v1/* --> B[Core Middleware (Vercel Serverless)]
  B -- route/guard/CORS/logging --> C[API Handlers (/api, /api/v1)]
  C -- proxy --> D[(UPSTREAM_API_BASE
Supabase Functions v1)]
  D -- JSON payload --> C --> B --> A
  
  subgraph Core
    B
    C
  end

  %% SSE/Event flow (optional)
  D -- events --> E[SSE/Notifications]
  E -. push .-> A
```
- **A**: واجهة Vite/React (يستدعي `/api/v1/...` فقط).
- **B**: طبقة وسطية موحدة (CORS/Logging/Auth/Input-Validation).
- **C**: نقاط النهاية (Handlers). تُنشأ تلقائيًا إن كانت مفقودة.
- **D**: Supabase Functions (`UPSTREAM_API_BASE`).

## Guarantees
- لا توجد نداءات مباشرة لـ Supabase من الواجهة.
- كل نداء يمر عبر **Core Middleware** ويُسجّل، ويخضع لـ CORS وAuth إن لزم.
- أي نهاية ناقصة تُولّد تلقائيًا كـ **Proxy handler** لتكتمل سلسلة start→end.
