# Core Middleware

- **CORS**: يسمح فقط من `FRONTEND_ORIGIN` المعتمد.
- **Logging**: طابع زمني + مسار + مدة التنفيذ.
- **Auth (اختياري)**: التحقق من توكن Supabase/Session عند المسارات الحساسة.
- **Error contract**: كل خطأ بصيغة `{ error, code, ref }` وبرمز HTTP مناسب.
