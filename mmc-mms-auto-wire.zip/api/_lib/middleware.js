export function withCore(handler){
  return async (req, res) => {
    const t0 = Date.now()
    const origin = req.headers.origin || ''
    const allow = process.env.FRONTEND_ORIGIN || ''
    res.setHeader('Vary', 'Origin')
    if (allow && origin && origin === allow){
      res.setHeader('Access-Control-Allow-Origin', allow)
      res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS')
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization')
    }
    if (req.method === 'OPTIONS'){ res.status(204).end(); return }

    try{
      await handler(req, res)
    }catch(err){
      const ref = Math.random().toString(36).slice(2,8)
      console.error('[core:error]', ref, err)
      res.status(500).json({ error: 'internal', ref })
    }finally{
      const dt = Date.now()-t0
      console.log('[core:done]', req.method, req.url, dt+'ms')
    }
  }
}