export async function proxyToUpstream(req, res, subpath=''){
  const base = process.env.UPSTREAM_API_BASE || ''
  const url = base + (subpath.startsWith('/')? subpath : '/' + subpath)
  const r = await fetch(url, {
    method: req.method,
    headers: { 'Content-Type': 'application/json', 'Authorization': req.headers.authorization || '' },
    body: ['GET','HEAD'].includes(req.method) ? undefined : JSON.stringify(req.body||{})
  })
  const txt = await r.text()
  res.status(r.status).setHeader('Content-Type', r.headers.get('content-type')||'application/json')
  res.send(txt)
}
