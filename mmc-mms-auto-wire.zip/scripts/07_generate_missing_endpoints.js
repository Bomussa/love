#!/usr/bin/env node
/**
 * 07_generate_missing_endpoints.js
 * Reads reports/route-graph.json and creates proxy handlers for any frontend call
 * that lacks a concrete API file under /api/v1/* .
 * Safe: writes under api/v1/auto/* and updates vercel.json if needed.
 */
import fs from 'fs'
import path from 'path'

const ROOT = process.cwd()
const REPORT = path.join(ROOT, 'reports', 'route-graph.json')
const API_DIR = path.join(ROOT, 'api', 'v1', 'auto')
const LIB_DIR = path.join(ROOT, 'api', '_lib')

function ensureDir(p){ fs.mkdirSync(p, { recursive: true }) }

function makeHandlerBody(subpath){
  return `import { withCore } from '../_lib/middleware.js'\nimport { proxyToUpstream } from '../_lib/proxy.js'\n\nexport default withCore(async (req, res) => {\n  await proxyToUpstream(req, res, '${subpath}')\n})\n`
}

function apiPathFor(callPath){
  // callPath like /api/v1/queue/start
  const sub = callPath.replace(/^\/api\/v1\/?/, '')
  const file = sub.split('/').map(s => s.replace(/[^a-zA-Z0-9_-]/g,'')).filter(Boolean)
  return { sub, filePath: path.join(API_DIR, ...file) + '.js' }
}

function main(){
  if (!fs.existsSync(REPORT)){
    console.error('Missing report:', REPORT)
    process.exit(2)
  }
  const data = JSON.parse(fs.readFileSync(REPORT,'utf8'))
  const calls = Array.from(new Set((data.frontend_calls||[]).map(x => x.path).filter(Boolean)))
  const handlers = new Set((data.api_handlers||[]).map(x => x.file))

  ensureDir(API_DIR); ensureDir(LIB_DIR)

  let created = 0
  for (const cp of calls){
    if (!cp.startsWith('/api/v1/')) continue
    const { sub, filePath } = apiPathFor(cp)

    // If there is already a handler matching this path we skip
    const exists = fs.existsSync(filePath)
    if (exists) continue

    fs.mkdirSync(path.dirname(filePath), { recursive: true })
    fs.writeFileSync(filePath, makeHandlerBody('/'+sub), 'utf8')
    created++
  }
  console.log(JSON.stringify({ created, dir: API_DIR }, null, 2))
}

main()
