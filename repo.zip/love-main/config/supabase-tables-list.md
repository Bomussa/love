# قائمة جداول Supabase

**المشروع:** MMC-MMS  
**التاريخ:** 08 نوفمبر 2025  
**المصدر:** https://supabase.com/dashboard/project/rujwuruuosffcxazymit

---

## إحصائيات

- **إجمالي الجداول:** 30
- **Schema:** public
- **قاعدة البيانات:** PostgreSQL

---

## قائمة الجداول الكاملة

### 1. Core Tables (الجداول الأساسية)

| # | اسم الجدول | الوصف | RLS |
|---|------------|-------|-----|
| 1 | `admins` | المسؤولون | ✅ |
| 2 | `patients` | المرضى | ✅ |
| 3 | `clinics` | العيادات | ✅ |
| 4 | `queue` | قائمة الانتظار | ✅ |
| 5 | `routes` | المسارات | ✅ |
| 6 | `route_steps` | خطوات المسار | ✅ |

### 2. Queue Management (إدارة الطوابير)

| # | اسم الجدول | الوصف | RLS |
|---|------------|-------|-----|
| 7 | `queue_admin_view` | عرض إداري للطابور | ⚠️ |
| 8 | `queue_audit` | تدقيق الطابور | ⚠️ |
| 9 | `queue_pending` | الطابور المعلق | ⚠️ |
| 10 | `queue_resettle` | إعادة ترتيب الطابور | ⚠️ |
| 11 | `queue_backup_20251101_000000` | نسخة احتياطية | ❌ |

### 3. Clinic Management (إدارة العيادات)

| # | اسم الجدول | الوصف | RLS |
|---|------------|-------|-----|
| 12 | `clinic_counters` | عدادات العيادات | ✅ |
| 13 | `clinic_pins` | أرقام PIN للعيادات | ✅ |
| 14 | `clinic_queue_reservations` | حجوزات الطابور | ✅ |

### 4. System & Configuration (النظام والإعدادات)

| # | اسم الجدول | الوصف | RLS |
|---|------------|-------|-----|
| 15 | `app_settings` | إعدادات التطبيق | ✅ |
| 16 | `organization` | بيانات المنظمة | ✅ |
| 17 | `pins` | أرقام PIN | ✅ |
| 18 | `sessions` | الجلسات | ✅ |
| 19 | `ip_sessions` | جلسات IP | ✅ |

### 5. Logging & Auditing (السجلات والتدقيق)

| # | اسم الجدول | الوصف | RLS |
|---|------------|-------|-----|
| 20 | `audit_logs` | سجلات التدقيق | ✅ |
| 21 | `error_log` | سجل الأخطاء | ⚠️ |
| 22 | `cache_logs` | سجلات الذاكرة المؤقتة | ✅ |
| 23 | `events` | الأحداث | ✅ |

### 6. Reporting & Analytics (التقارير والتحليلات)

| # | اسم الجدول | الوصف | RLS |
|---|------------|-------|-----|
| 24 | `reports` | التقارير | ✅ |
| 25 | `chart_data` | بيانات الرسوم البيانية | ✅ |
| 26 | `daily_barcode_usage` | استخدام الباركود اليومي | ✅ |

### 7. Advanced Features (ميزات متقدمة)

| # | اسم الجدول | الوصف | RLS |
|---|------------|-------|-----|
| 27 | `notifications` | الإشعارات | ⚠️ |
| 28 | `rate_limits` | حدود المعدل | ✅ |
| 29 | `call_engine_state` | حالة محرك الاستدعاء | ✅ |
| 30 | `scheduler_jobs` | مهام الجدولة | ✅ |

---

## تصنيف حسب الوظيفة

### إدارة المرضى والعيادات (8 جداول)
- patients, clinics, queue, clinic_counters, clinic_pins, clinic_queue_reservations, routes, route_steps

### إدارة الطوابير (5 جداول)
- queue, queue_admin_view, queue_audit, queue_pending, queue_resettle

### النظام والأمان (5 جداول)
- admins, app_settings, sessions, ip_sessions, pins

### السجلات والتدقيق (4 جداول)
- audit_logs, error_log, cache_logs, events

### التقارير والتحليلات (3 جداول)
- reports, chart_data, daily_barcode_usage

### الميزات المتقدمة (4 جداول)
- notifications, rate_limits, call_engine_state, scheduler_jobs

### أخرى (1 جدول)
- organization

---

## حالة Row Level Security (RLS)

| الحالة | العدد | النسبة |
|--------|------|--------|
| ✅ مفعّل | 24 | 80% |
| ⚠️ غير مفعّل | 5 | 17% |
| ❌ نسخة احتياطية | 1 | 3% |

---

## الجداول التي تحتاج RLS

الجداول التالية يُنصح بتفعيل RLS عليها:

1. `error_log` - سجل الأخطاء
2. `notifications` - الإشعارات  
3. `queue_admin_view` - عرض إداري
4. `queue_audit` - تدقيق الطابور
5. `queue_pending` - الطابور المعلق

---

## ملاحظات مهمة

1. ✅ معظم الجداول الأساسية محمية بـ RLS
2. ⚠️ بعض جداول Queue غير محمية (قد يكون مقصودًا)
3. ✅ جداول Admins و Patients محمية بشكل جيد
4. 📊 يوجد جدول نسخة احتياطية (queue_backup) يمكن أرشفته
5. 🔄 النظام يستخدم معمارية متقدمة مع جداول تدقيق

---

## العلاقات الرئيسية

```
patients (1) ─── (N) queue
clinics (1) ─── (N) queue
clinics (1) ─── (N) clinic_counters
clinics (1) ─── (N) clinic_pins
routes (1) ─── (N) route_steps
admins (1) ─── (N) audit_logs
```

---

**آخر تحديث:** 08 نوفمبر 2025
