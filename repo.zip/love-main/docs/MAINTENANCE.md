# 🔧 دليل الصيانة

## النسخ الاحتياطي

\`\`\`bash
# نسخ احتياطي لقاعدة البيانات
npm run db:backup

# استعادة
npm run db:restore backup.sql
\`\`\`

## المراقبة

- Vercel Dashboard: https://vercel.com/bomussa/love
- Supabase Dashboard: https://supabase.com/dashboard/project/rujwuruuosffcxazymit

## الصيانة الدورية

- ✅ فحص السجلات أسبوعيًا
- ✅ نسخ احتياطي يومي
- ✅ تحديث الاعتماديات شهريًا

---
**آخر تحديث:** 08 نوفمبر 2025
