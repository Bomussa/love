# مصفوفة المسارات (Start → End)

يُعاد توليدها من `scripts/04_build_route_graph.py`:
- `frontend_calls`: أين تُستدعى `/api/*` في الواجهة
- `api_handlers`: ما هي نقاط النهاية الفعلية تحت `api/` أو `pages/api` أو `functions/*`
- `upstream_links`: كيف يتوجه كل API إلى Supabase Functions (`UPSTREAM_API_BASE`) أو غيره

أي صف يفتقد حلقة في السلسلة = يجب إصلاحه أو حذفه.
