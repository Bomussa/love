# الهيكل المعتمد لما بعد الدمج (Monorepo)

```
/
├─ apps/
│  ├─ web/            # واجهة Vite/React الوحيدة المعتمدة
│  └─ api/            # وظائف Vercel/Node (أو Edge)
├─ packages/          # كل المستودعات المُدمجة كوحدات مستقلة (lib/ui/shared/…)
│  ├─ <repo-a>/
│  └─ <repo-b>/
├─ docs/
├─ reports/           # تقارير الفحص التلقائي
├─ config/            # قوائم include/exclude
├─ scripts/
└─ .github/workflows/
```
