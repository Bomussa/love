# MMC‑MMS — دليل دمج وتنظيف المستودعات (نهائي)

> الهدف: تحويل جميع المستودعات ذات العلاقة (≈200) إلى **هيكل واحد نظيف وموثّق** داخل `love` (أو Monorepo) بدون تكرار أو تعارض، والتحقق بأن كل مسار من **start → end** صحيح (واجهة → خدمة → API → Upstream).

## 0) المتطلبات
- Git 2.40+
- Node.js 18+ و Python 3.10+
- GitHub CLI (`gh`) مع صلاحية القراءة/الكتابة
- متغيرات بيئة:
  - `GH_USER` = حساب GitHub (مثال: `Bomussa`)
  - `GITHUB_TOKEN` = PAT بصلاحية `repo`

## 1) استنساخ كل المستودعات (Pull ALL)
```bash
bash scripts/01_clone_all.sh
# ينشئ مجلد work/repos ويستنسخ كل المستودعات من الحساب (User + Orgs)
```

## 2) الفحص الشامل:
```bash
# 2.1 — تدقيق البنية والإطارات وملفات البيئة
node scripts/02_audit_repo.js > reports/audit.json

# 2.2 — كشف التطابقات/التكرارات بالهاش
python3 scripts/03_find_duplicates.py > reports/duplicates.json

# 2.3 — بناء خريطة المسارات من الواجهة → الخدمات → API
python3 scripts/04_build_route_graph.py > reports/route-graph.json
```

> ناتج التقارير يوجد في `reports/` ويُنشأ تلقائياً. هذه هي **مصادر الحقيقة** لقرارات الدمج/الحذف.

## 3) اختيار ما يُدمج وما يُستبعد
- عدّل الملف: `config/repos-include.txt` لإجبار إدراج مستودعات معينة.
- وعدّل الملف: `config/repos-exclude.txt` لاستبعاد المستودعات غير المستخدمة/المكررة.
- يمكن تعديل قواعد الاستثناء في `scripts/02_audit_repo.js` (أنماط التجاهل).

## 4) إنشاء Monorepo آمن داخل `love`
> **بدون أي حذف مباشر** — الدمج يتم تحت `packages/*` كي يبقى التاريخ محفوظاً.
```bash
bash scripts/05_migrate_to_monorepo.sh
```
- يُنشئ: `packages/<repo-name>` لكل مستودع معتمد
- ينقل أي API/Functions إلى `apps/api` عند الإمكان، والواجهة إلى `apps/web`
- يسجل روابط التبعية بين الحزم

## 5) فحص المسارات End‑to‑End
```bash
node scripts/06_wire_env_check.js > reports/env-check.json
python3 scripts/04_build_route_graph.py > reports/route-graph.json
# تحقّق أن كل استدعاء من الواجهة يملك مقابل API فعلي،
# وأن كل API مرتبط بـ upstream صحيح (Supabase/Cloudflare/Vercel Functions).
```

## 6) GitHub Actions — توليد تقرير تلقائي
- ملف العمل: `.github/workflows/audit.yml`
- يشغَّل بـ `workflow_dispatch`، ويرفع `audit.json` و`duplicates.json` و`route-graph.json` كـArtifacts.

## 7) إغلاق الحلقة (Clean)
- استخدم `reports/duplicates.json` لحذف الملفات المكررة/غير المستخدمة (PR آمن).
- راجع `reports/route-graph.json` لأي فجوة (واجهة تستدعي مسار غير موجود → أصلحه أو احذفه).
- بعد الدمج النهائي: ثبّت البنية في `docs/STRUCTURE.md` داخل المستودع الرئيسي.

> جميع الأوامر **غير مدمّرة**؛ التنظيف الفعلي يتم عبر PRs واضحة، لتفادي أي فقدان.
