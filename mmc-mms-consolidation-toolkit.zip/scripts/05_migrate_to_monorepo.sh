#!/usr/bin/env bash
# 05_migrate_to_monorepo.sh — دمج المستودعات بأمان داخل love تحت packages/* + apps/*
set -euo pipefail
ROOT="$(pwd)"
WORK="$ROOT/work"
REPOS_DIR="$WORK/repos"
TARGET_DIR="$ROOT/monorepo"
mkdir -p "$TARGET_DIR/packages" "$TARGET_DIR/apps" "$ROOT/reports"

echo "[i] تهيئة monorepo (إن لم يوجد)"
if [ ! -d "$TARGET_DIR/.git" ]; then
  git init "$TARGET_DIR"
  (cd "$TARGET_DIR" && git commit -m "init empty" --allow-empty)
fi

echo "[i] قراءة قوائم include/exclude"
INCLUDE_PATTERNS="$(cat config/repos-include.txt || true)"
EXCLUDE_PATTERNS="$(cat config/repos-exclude.txt || true)"

should_include() {
  local name="$1"
  # include إذا طابق أي سطر في include، واستبعد إذا طابق exclude
  if echo "$EXCLUDE_PATTERNS" | grep -Eiq "$name"; then return 1; fi
  if echo "$INCLUDE_PATTERNS" | grep -Eiq "$name"; then return 0; fi
  # افتراضيًا: ضُمّ كل شيء غير Archived (نظرًا لأننا جلبنا غير المؤرشف فقط)
  return 0
}

for repo in $(ls "$REPOS_DIR"); do
  [ -d "$REPOS_DIR/$repo/.git" ] || continue
  if ! should_include "$repo"; then
    echo "[skip] $repo (excluded)"
    continue
  fi
  echo "[+] دمج $repo → packages/$repo"
  (cd "$TARGET_DIR" && git remote remove "r_$repo" 2>/dev/null || true)
  (cd "$TARGET_DIR" && git remote add "r_$repo" "$REPOS_DIR/$repo")
  (cd "$TARGET_DIR" && git fetch "r_$repo")
  (cd "$TARGET_DIR" && git subtree add --prefix "packages/$repo" "r_$repo" HEAD -m "subtree: add $repo" || true)
done

echo "[i] تجهيز apps/web و apps/api إن لم تكن موجودة"
mkdir -p "$TARGET_DIR/apps/web" "$TARGET_DIR/apps/api"
echo "[✓] تم — راجع reports/* للتأكد قبل أي حذف"
