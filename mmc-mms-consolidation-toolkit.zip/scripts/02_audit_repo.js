#!/usr/bin/env node
/**
 * 02_audit_repo.js
 * يفحص كل مستودع: إطار العمل، وجود api، vercel.json، supabase/functions،
 * ملفات env، وملفات محتملة للتكرار. يخرج JSON شامل.
 */
const fs = require('fs');
const path = require('path');

const ROOT = process.cwd();
const REPOS_DIR = path.join(ROOT, 'work', 'repos');
const OUT_DIR = path.join(ROOT, 'reports');
fs.mkdirSync(OUT_DIR, { recursive: true });

function readJSON(p){ try { return JSON.parse(fs.readFileSync(p,'utf8')); } catch { return null; } }
function exists(p){ try { fs.accessSync(p); return true; } catch { return false; } }
function firstExists(...paths){ return paths.find(exists); }

function detectFramework(repoDir) {
  if (exists(path.join(repoDir, 'vite.config.ts')) || exists(path.join(repoDir,'vite.config.js'))) return 'vite';
  if (exists(path.join(repoDir, 'next.config.js')) || exists(path.join(repoDir,'next.config.mjs'))) return 'nextjs';
  if (exists(path.join(repoDir, 'astro.config.mjs'))) return 'astro';
  if (exists(path.join(repoDir, 'svelte.config.js'))) return 'sveltekit';
  return 'unknown';
}

function findAPISurfaces(repoDir) {
  const surfaces = [];
  const apiDirs = [
    'api', 'pages/api', 'server/api', 'functions', 'supabase/functions',
    'worker', 'workers', 'cloudflare', 'edge-functions'
  ];
  for (const d of apiDirs) {
    const full = path.join(repoDir, d);
    if (exists(full)) surfaces.push(d);
  }
  return surfaces;
}

function auditRepo(name) {
  const repoDir = path.join(REPOS_DIR, name);
  const pkg = readJSON(path.join(repoDir, 'package.json'));
  const vercel = readJSON(path.join(repoDir, 'vercel.json'));
  const framework = detectFramework(repoDir);
  const api = findAPISurfaces(repoDir);
  const envFiles = ['.env', '.env.local', '.env.production'].filter(f => exists(path.join(repoDir, f)));
  const supabaseConfig = firstExists(path.join(repoDir,'supabase','config.toml'), path.join(repoDir,'supabase','functions'));
  const result = {
    repo: name,
    framework, api, hasVercel: !!vercel,
    envFiles, hasSupabase: !!supabaseConfig,
    pkgScripts: pkg?.scripts || {},
    suspectedFrontend: exists(path.join(repoDir, 'src')),
    suspectedAPI: api.length>0
  };
  return result;
}

const repos = fs.existsSync(REPOS_DIR) ? fs.readdirSync(REPOS_DIR).filter(d=>fs.existsSync(path.join(REPOS_DIR,d,'.git'))) : [];
const audit = repos.map(auditRepo);
fs.writeFileSync(path.join(OUT_DIR,'audit.json'), JSON.stringify(audit,null,2));
console.log(JSON.stringify(audit,null,2));
