#!/usr/bin/env bash
set -euo pipefail
: "${GH_USER:?GH_USER must be set}"
: "${GITHUB_TOKEN:?GITHUB_TOKEN must be set}"

ROOT="$(pwd)"
WORK="$ROOT/work"
REPOS_DIR="$WORK/repos"
mkdir -p "$REOS_DIR" 2>/dev/null || true
mkdir -p "$REPOS_DIR"

echo "[i] Listing repos for user: $GH_USER"
gh auth status || gh auth login --with-token <<<"$GITHUB_TOKEN"

# User repos
gh repo list "$GH_USER" --limit 400 --json name,sshUrl,visibility,archived --jq '.[] | select(.archived==false) | [.name, .sshUrl] | @tsv' > "$WORK/user_repos.tsv" || true

# Optional: orgs
gh api user/orgs --jq '.[].login' > "$WORK/orgs.txt" || true
> "$WORK/org_repos.tsv"
while read -r ORG; do
  [[ -z "$ORG" ]] && continue
  echo "[i] Listing org repos: $ORG"
  gh repo list "$ORG" --limit 400 --json name,sshUrl,visibility,archived --jq '.[] | select(.archived==false) | [.name, .sshUrl] | @tsv' >> "$WORK/org_repos.tsv" || true
done < "$WORK/orgs.txt"

cat "$WORK/user_repos.tsv" "$WORK/org_repos.tsv" 2>/dev/null | sort -u > "$WORK/all_repos.tsv"

echo "[i] Cloning..."
while IFS=$'\t' read -r NAME SSHURL; do
  [[ -z "$NAME" || -z "$SSHURL" ]] && continue
  if [[ -d "$REPOS_DIR/$NAME/.git" ]]; then
    echo "  [=] $NAME exists → pulling"
    git -C "$REPOS_DIR/$NAME" pull --ff-only || true
  else
    echo "  [+] cloning $NAME"
    git clone --filter=blob:none "$SSHURL" "$REPOS_DIR/$NAME" || true
  fi
done < "$WORK/all_repos.tsv"

echo "[✓] Done: $REPOS_DIR"
