#!/usr/bin/env python3
# 04_build_route_graph.py — يبني خريطة: frontend_calls → api_handlers → upstream_links
import os, re, json, pathlib

ROOT = os.getcwd()
REPOS_DIR = os.path.join(ROOT, 'work', 'repos')
RESULT = {"frontend_calls": [], "api_handlers": [], "upstream_links": []}

# 1) Frontend calls: ابحث عن fetch/axios لـ /api أو VITE_API_BASE_URL
FE_PATTERNS = [
    re.compile(r'fetch\(\s*[`\'"](/api[^`\'"]*)[`\'"]', re.I),
    re.compile(r'axios\.(get|post|put|delete)\(\s*[`\'"](/api[^`\'"]*)[`\'"]', re.I),
    re.compile(r'VITE_API_BASE_URL\s*\+?\s*[`\'"]([^`\'"]+)')
]

def scan_file(path):
    try:
        with open(path,'r',encoding='utf-8',errors='ignore') as f:
            return f.read()
    except:
        return ''

def walk_repo(repo):
    rdir = os.path.join(REPOS_DIR, repo)
    for root, dirs, files in os.walk(rdir):
        dirs[:] = [d for d in dirs if d not in ('.git','node_modules','dist','.next','.vercel','build','coverage','.output')]
        for fn in files:
            if not fn.endswith(('.js','.jsx','.ts','.tsx','.mjs','.cjs')):
                continue
            p = os.path.join(root, fn)
            txt = scan_file(p)
            for rgx in FE_PATTERNS:
                for m in rgx.finditer(txt):
                    RESULT["frontend_calls"].append({"repo":repo,"file":p,"call":m.group(0),"path":m.group(2) if m.lastindex and m.lastindex>=2 else m.group(1)})

            # API handlers (Next/Vercel style)
            if '/api/' in p.replace('\\','/'):
                if re.search(r'export\s+default|module\.exports|export\s+async\s+function', txt):
                    RESULT["api_handlers"].append({"repo":repo,"file":p})

            # Upstream links (إلى Supabase Functions)
            for m in re.finditer(r'UPSTREAM_API_BASE|supabase\.functions|fetch\(\s*process\.env\.UPSTREAM_API_BASE', txt):
                RESULT["upstream_links"].append({"repo":repo,"file":p,"hit":m.group(0)})

repos = [d for d in os.listdir(REPOS_DIR) if os.path.isdir(os.path.join(REPOS_DIR,d, '.git'))]
for r in repos:
    walk_repo(r)

print(json.dumps(RESULT, ensure_ascii=False, indent=2))
