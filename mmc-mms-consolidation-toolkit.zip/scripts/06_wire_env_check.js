#!/usr/bin/env node
// 06_wire_env_check.js — يتحقق أن env في الكود تتوافق مع ENV.md
const fs = require('fs');
const path = require('path');
const ROOT = process.cwd();
const OUT = path.join(ROOT,'reports');
fs.mkdirSync(OUT,{recursive:true});

const EXPECT = {
  VITE_SUPABASE_URL: /https:\/\/yeyntvrpkwcbihvbaemm\.supabase\.co/i,
  UPSTREAM_API_BASE: /https:\/\/yeyntvrpkwcbihvbaemm\.supabase\.co\/functions\/v1/i,
  VITE_API_BASE_URL: /https:\/\/mmc-mms\.com\/api\/v1/i
};

function searchEnvRefs(dir) {
  const hits = [];
  function walk(d){
    for (const e of fs.readdirSync(d,{withFileTypes:true})) {
      const p = path.join(d,e.name);
      if (e.isDirectory()) {
        if (['.git','node_modules','dist','.next','.vercel','build'].includes(e.name)) continue;
        walk(p);
      } else if (/\.(js|jsx|ts|tsx|mjs|cjs)$/.test(e.name)) {
        const txt = fs.readFileSync(p,'utf8');
        for (const [k,rx] of Object.entries(EXPECT)) {
          if (new RegExp(k).test(txt) && !rx.test(txt)) {
            hits.push({file:p, var:k, note:'Mismatch EXPECT pattern'});
          }
        }
      }
    }
  }
  walk(dir);
  return hits;
}

const reposDir = path.join(ROOT,'work','repos');
const repos = fs.existsSync(reposDir)?fs.readdirSync(reposDir).filter(n=>fs.existsSync(path.join(reposDir,n,'.git'))):[];
const res = [];
for (const r of repos) {
  res.push(...searchEnvRefs(path.join(reposDir,r)));
}
fs.writeFileSync(path.join(OUT,'env-check.json'), JSON.stringify(res,null,2));
console.log(JSON.stringify(res,null,2));
