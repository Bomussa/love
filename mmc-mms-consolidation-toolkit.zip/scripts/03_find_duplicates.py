#!/usr/bin/env python3
# 03_find_duplicates.py — يحسب SHA256 لكل ملف ويخرج مجموعات الملفات المتطابقة عبر كل المستودعات
import os, sys, hashlib, json, re
ROOT = os.getcwd()
REPOS_DIR = os.path.join(ROOT, 'work', 'repos')
IGNORE_DIRS = {'.git','node_modules','dist','build','.next','.vercel','coverage','.cache','.output'}
IGNORE_EXT = {'.png','.jpg','.jpeg','.webp','.gif','.lock','.zip','.tar','.gz','.pdf','.mp4','.mov','.avi','.ico'}

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1<<20), b''):
            h.update(chunk)
    return h.hexdigest()

dups = {}
for repo in (os.listdir(REPOS_DIR) if os.path.isdir(REPOS_DIR) else []):
    rdir = os.path.join(REPOS_DIR, repo)
    for root,dirs,files in os.walk(rdir):
        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]
        for f in files:
            p = os.path.join(root,f)
            ext = os.path.splitext(f)[1].lower()
            if ext in IGNORE_EXT: 
                continue
            try:
                s = os.stat(p).st_size
                if s == 0: 
                    continue
                h = sha256_file(p)
                dups.setdefault(h, []).append(p)
            except Exception as e:
                pass

groups = {h:paths for h,paths in dups.items() if len(paths)>1}
print(json.dumps(groups, indent=2, ensure_ascii=False))
