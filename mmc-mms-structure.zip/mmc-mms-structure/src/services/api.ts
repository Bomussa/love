const base = import.meta.env.VITE_API_BASE_URL || '/api/v1'
export async function post<T=any>(path:string, body:any){
  const r = await fetch(`${base}${path}`, {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(body)
  })
  if(!r.ok) throw new Error(`HTTP ${r.status}`)
  return r.json() as Promise<T>
}
