# RUNBOOK — إجراءات التشغيل القياسية

1) **تسجيل الدخول**
   - GitHub: حساب (Bomussa)
   - Supabase: Project `Mmc-mms` → Settings → API (نسخ URL + anon)
   - Vercel: Project `love` → Settings → Environment Variables

2) **تحديث المتغيّرات**
   - حدّث `VITE_SUPABASE_URL` و `VITE_SUPABASE_ANON_KEY` و `UPSTREAM_API_BASE` و `VITE_API_BASE_URL` وفق docs/ENV.md

3) **إعادة النشر**
   - من Vercel → Deployments → Redeploy

4) **التحقق**
   - فتح الموقع → أدوات المطوّر (Network) → تأكد أن `/api/v1` تُرجع 200
   - تنفيذ `npm run check:env` محليًا للتحقق من تماسك القيم

