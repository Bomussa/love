# CHECKS — Quality Gates

- ESLint/Typecheck خالي من الأخطاء: `npm run lint && npm run typecheck`
- لا ملفات غير مستخدمة: `npm run check:dead`
- تماسك المتغيرات: `npm run check:env`
