# TROUBLESHOOTING — استكشاف الأخطاء

- **Login failed / 403**: تأكد أن `UPSTREAM_API_BASE` يشير للمشروع الصحيح في Supabase وأنه تمت إعادة النشر.
- **502 BAD_GATEWAY**: تحقق من `vercel.json` (الـ routes) وعدم استخدام متغيرات داخل `rewrites` مباشرة.
- **تعارض بيئات**: تأكد أن Production/Preview في Vercel تحمل نفس المفاتيح (مع اختلاف القيم إن لزم).

