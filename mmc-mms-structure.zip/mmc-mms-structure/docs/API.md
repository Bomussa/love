# API — توصيف مبسّط

- `GET /api` → `{ ok: true, root: '/api' }`
- `GET|POST /api/v1` → `{ version:'v1', status:'ready' }`

> وسّع هذا الملف لوصف جميع مساراتك الفعلية مثل `/api/start-session`, `/api/queue/*`.
