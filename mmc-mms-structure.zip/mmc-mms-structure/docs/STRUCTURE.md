# STRUCTURE — هيكل المجلدات والملفات (المعتمد)

```
/ (root)
├── vercel.json                 # مسارات وإعادة كتابة API
├── package.json                # سكربتات البناء والضبط
├── tsconfig.json               # إعدادات TypeScript
├── vite.config.ts              # إعدادات Vite
├── .editorconfig .gitignore    # أدوات التطوير
├── /src                        # الواجهة الأمامية (Vite/React)
│   ├── components/             # مكوّنات UI
│   ├── pages/                  # صفحات أساسية (App.tsx نقطة الدخول)
│   ├── routes/                 # تعريف المسارات (اختياري)
│   ├── lib/                    # ثوابت ومكتبات مشتركة
│   ├── services/               # API client (يعتمد على VITE_API_BASE_URL)
│   ├── hooks/                  # Hooks
│   ├── styles/                 # CSS
│   └── assets/                 # صور وأيقونات
├── /api                        # وظائف Vercel Serverless
│   ├── _lib/                   # أدوات (response, supabase helper)
│   ├── index.js                # /api
│   └── v1/index.js             # /api/v1
└── /docs                       # وثائق التشغيل والصيانة
    ├── ENV.md                  # خريطة المتغيّرات عبر GitHub/Vercel/Supabase
    ├── RUNBOOK.md              # إجراءات التشغيل القياسية (SOP)
    ├── TROUBLESHOOTING.md      # استكشاف الأخطاء
    ├── CHECKS.md               # Quality Gates
    └── API.md                  # وصف مسارات الـ API
```
