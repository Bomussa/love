# ENV — خريطة المتغيّرات (المصدر الواحد للحقيقة)

| المجال | المتغيّر | أين يُخزّن | القيمة/المثال |
|---|---|---|---|
| Frontend | VITE_SUPABASE_URL | Vercel (Production/Preview) | https://yeyntvrpkwcbihvbaemm.supabase.co |
| Frontend | VITE_SUPABASE_ANON_KEY | Vercel | sbp_... (anon key) |
| Frontend | VITE_API_BASE_URL | Vercel | https://mmc-mms.com/api/v1 |
| Server | UPSTREAM_API_BASE | Vercel | https://yeyntvrpkwcbihvbaemm.supabase.co/functions/v1 |

> **ملاحظة:** أي تغيير على هذه القيم يتطلب إعادة نشر Vercel ليصبح فعّالًا.
