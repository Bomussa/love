export const ok = (data) => new Response(JSON.stringify(data), {status:200, headers:{'Content-Type':'application/json'}})
export const bad = (msg, code=400) => new Response(JSON.stringify({error:msg}), {status:code, headers:{'Content-Type':'application/json'}})
