export const upstream = (endpoint='') => {
  const base = process.env.UPSTREAM_API_BASE || ''
  return `${base}${endpoint.startsWith('/')?endpoint:`/${endpoint}`}`
}
