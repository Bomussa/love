import { ok, bad } from '../_lib/response.js'
export default async function handler(req, res){
  if(req.method!=='POST' && req.method!=='GET') return res.status(405).json({error:'method'})
  return res.status(200).json({version:'v1', status:'ready'})
}
