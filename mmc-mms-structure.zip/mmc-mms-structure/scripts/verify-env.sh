#!/usr/bin/env bash
set -euo pipefail
REQ_URL='https://yeyntvrpkwcbihvbaemm.supabase.co'
echo "[check] VITE_SUPABASE_URL=$VITE_SUPABASE_URL"
echo "[check] UPSTREAM_API_BASE=$UPSTREAM_API_BASE"
if [[ "${VITE_SUPABASE_URL:-}" != "$REQ_URL" ]]; then
  echo "[FAIL] VITE_SUPABASE_URL mismatch"; exit 1
fi
if [[ "${UPSTREAM_API_BASE:-}" != "$REQ_URL/functions/v1" ]]; then
  echo "[FAIL] UPSTREAM_API_BASE mismatch"; exit 1
fi
echo "[OK] ENV looks consistent"
